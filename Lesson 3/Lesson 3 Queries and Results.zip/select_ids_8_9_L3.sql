/************
Gabe Baduqui
CIS276DA
Lesson 3
************/


-- 1Ci
SELECT * FROM score WHERE event_id = 5 AND student_id IN (8,9); 