/********************
Gabe Baduqui
CIS276
Lesson 8 Project
Question 5
********************/

/* Question 5 */
select * from mysql.user;