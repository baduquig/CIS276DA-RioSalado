/********************
Gabe Baduqui
CIS276
Lesson 9 Project
Question 4
********************/

/* Question 4 */
select * from mysql.user;

